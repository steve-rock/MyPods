//
//  SwiftyAds.h
//  SwiftyAds
//
//  Created by MinhNH on 04/05/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftyAds.
FOUNDATION_EXPORT double SwiftyAdsVersionNumber;

//! Project version string for SwiftyAds.
FOUNDATION_EXPORT const unsigned char SwiftyAdsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftyAds/PublicHeader.h>


